-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2015 at 04:55 AM
-- Server version: 5.6.15-log
-- PHP Version: 5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `drh`
--
CREATE DATABASE IF NOT EXISTS `drh` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `drh`;

-- --------------------------------------------------------

--
-- Table structure for table `departement`
--

DROP TABLE IF EXISTS `departement`;
CREATE TABLE IF NOT EXISTS `departement` (
  `num_departement` char(4) CHARACTER SET latin1 NOT NULL,
  `nom_departement` varchar(40) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`num_departement`),
  UNIQUE KEY `nom_departement` (`nom_departement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `directeur_departement`
--

DROP TABLE IF EXISTS `directeur_departement`;
CREATE TABLE IF NOT EXISTS `directeur_departement` (
  `num_employe` int(11) NOT NULL,
  `num_departement` char(4) CHARACTER SET latin1 NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`num_employe`,`num_departement`),
  KEY `num_departement` (`num_departement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `num_employe` int(11) NOT NULL,
  `ddn` date NOT NULL,
  `prenom` varchar(14) CHARACTER SET latin1 NOT NULL,
  `nom` varchar(16) CHARACTER SET latin1 NOT NULL,
  `sexe` enum('M','F') CHARACTER SET latin1 NOT NULL,
  `date_embauche` date NOT NULL,
  PRIMARY KEY (`num_employe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `employe_departement`
--

DROP TABLE IF EXISTS `employe_departement`;
CREATE TABLE IF NOT EXISTS `employe_departement` (
  `num_employe` int(11) NOT NULL,
  `num_departement` char(4) CHARACTER SET latin1 NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`num_employe`,`num_departement`),
  KEY `num_departement` (`num_departement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `salaire`
--

DROP TABLE IF EXISTS `salaire`;
CREATE TABLE IF NOT EXISTS `salaire` (
  `num_employe` int(11) NOT NULL,
  `salaire` int(11) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`num_employe`,`date_debut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `titre`
--

DROP TABLE IF EXISTS `titre`;
CREATE TABLE IF NOT EXISTS `titre` (
  `num_employe` int(11) NOT NULL,
  `titre` varchar(50) CHARACTER SET latin1 NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date DEFAULT NULL,
  PRIMARY KEY (`num_employe`,`titre`,`date_debut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `directeur_departement`
--
ALTER TABLE `directeur_departement`
  ADD CONSTRAINT `directeur_departement_ibfk_1` FOREIGN KEY (`num_employe`) REFERENCES `employe` (`num_employe`) ON DELETE CASCADE,
  ADD CONSTRAINT `directeur_departement_ibfk_2` FOREIGN KEY (`num_departement`) REFERENCES `departement` (`num_departement`) ON DELETE CASCADE;

--
-- Constraints for table `employe_departement`
--
ALTER TABLE `employe_departement`
  ADD CONSTRAINT `employe_departement_ibfk_1` FOREIGN KEY (`num_employe`) REFERENCES `employe` (`num_employe`) ON DELETE CASCADE,
  ADD CONSTRAINT `employe_departement_ibfk_2` FOREIGN KEY (`num_departement`) REFERENCES `departement` (`num_departement`) ON DELETE CASCADE;

--
-- Constraints for table `salaire`
--
ALTER TABLE `salaire`
  ADD CONSTRAINT `salaire_ibfk_1` FOREIGN KEY (`num_employe`) REFERENCES `employe` (`num_employe`) ON DELETE CASCADE;

--
-- Constraints for table `titre`
--
ALTER TABLE `titre`
  ADD CONSTRAINT `titre_ibfk_1` FOREIGN KEY (`num_employe`) REFERENCES `employe` (`num_employe`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
